#a
from dll.system import choose
from dll.system import listdir
from dll.system import color
from dll.system import wait
from dll.system import zipper
from dll.system import check_uuid
from dll.system import find_file
from dll.system import download
while __name__ == '__main__':
    a = input("")
    choose.Choose(a)