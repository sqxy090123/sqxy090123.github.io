import os
import requests
from dll.system import zipper


def Download_py(name):
    try:
        if not os.path.exists("./data/"):
            os.mkdir("./data/")
        URL = "https://sqxy090123.github.io/py/about/{}.py".format(name)
        from urllib.request import urlretrieve
        w = "./data/{}.py".format(name)
        urlretrieve(URL, w)
        if os.path.isfile("$.zip"):
            with open(w, "r") as dt:
                data = dt.readlines()
            zipper.write("$.zip","dll/system/{}.py".format(name),"".join(str(data)))
        else:
            with open(w, "r") as dt:
                data = dt.readlines()
            try:
                open("./$/dll/system/{}.py".format(name), "r")
                print("已经有 '{}' 模块了\n如要更新, 试试指令download --upgrade {}".format(name, name))
            except FileNotFoundError:
                with open("./$/dll/system/{}.py".format(name), "a+") as n:
                    n.write("".join(str(data[-1])))
                os.remove(w)
                os.remove_dirs("./data")
                return True
    except Exception as Err:
        print("{}\n '{}'".format(Err, name))
        return False

def q(common):
    l = common.split(' ',1)
    str1 = "".join(str(l[0]))
    if str1 == "help":
        print("Usage:\n\tdownload [--common] file")
    if str1 == "upgrade":
        if zipper.is_zip("$"):
            pass
        
        else:
            try:
                open("./$/dll/system/{}.py".format("".join(str(l[1]))),"r")
                print("你还没有下载插件 '{}'".format("".join(str(l[1]))))
                return False
            except FileNotFoundError:
                pass
            with open("$/dll/system/{}.py".format("".join(str(l[1]))),"w") as n:
                URL = "https://sqxy090123.github.io/py/about/{}.py".format(name)
                w = "./$/dll/data/{}.py".format("".join(str(l[1])))
                urlretrieve(URL, w)