#有井号提示为插件
try:
    from dll.system import listdir
    from dll.system import color
    from dll.system import wait
    from dll.system import zipper
    from dll.system import check_uuid
    from dll.system import find_file
    from dll.system import download
except Exception as Err:
    pass

# Error
class Error_1(Exception):
    def __init__(self, message):
        self.message = message

# check
def choose_check(given):
    check_uuid.check(given)

def download_check(given):
    l = given.split(' ',1)
    l2 = l[0]
    str2 = "".join(str(l2))
    if str2[0:1] == "-":
        if str2[1:2] == '-':
            download.q(str2[2:])
            return None
        else:
            pass
    else:
        pass
    try:
        download.Download_py(given)
        print("Ok")
    except:
        raise Error_1(given)
    


def Choose(words):
    return __init__(words)

def __init__(words):
    l = words.split(' ',1)
    l1 = l[0]
    str1 = "".join(str(l1))
    if str1 == "exit":
        if l[1]:
            try:
                exit(int("".join(str(l[1]))))
            except:
                exit()
        else:
            exit()
    if str1 == "check":
        if str(l[1])[0:1] == "-":
            if str(l[1])[1:2] == '-':
                if str(l[1])[2:] == "all":
                    return check_all_import()
        else:
            pass
        try:
            return choose_check("".join(str(l[1])))
        except IndexError:
            return choose_check("")
    if str1 == "download":
        try:
            print("".join(str(l[1])))
            return download_check("".join(str(l[1])))
        except IndexError:
            return download_check("")


def check_all_import():
    find_file.check_all()