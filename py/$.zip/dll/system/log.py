#4ed2f560-d2fd-11ed-b507-4f07b6f0a541

import time

class write():
    def __init__(self, message, file):
        with open(file, 'a+') as n:
            n.write(message)
    def Error_time(message, where):
        with open('latest_log.txt', 'a+') as l:
            l.write("[{}\\Error] Error return:\n    {} at {}\n".format(where, message, time.asctime()))
    def Info_time(message, where):
        with open('latest_log.txt', 'a+') as l:
            l.write("[{}\\Info] Success {} at {}\n".format(where,message, time.asctime()))