#79563b84-d2f4-11ed-bfc8-33f3a3610b93
#coding=utf-8

from dll.system import log
from dll.system import check_uuid


import os
class S():
    def __init__(self):
        self.dirPath = []
    def find():
        dirPath = []
        path = "$/dll/system"
        for dir in os.listdir(path):
            childDir = os.path.join(path, dir)
            if os.path.isdir(childDir):
               pass
            else:
                if childDir[-2:] == "py":
                    dirPath.append(childDir)
        return dirPath


def check_all():
    check_uuid.check_more(S.find())
 