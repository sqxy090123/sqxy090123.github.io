#4facc6fa-d2fd-11ed-ac1c-abd02ba6f14f
import time as t
from dll import system as sys
def second(second):
    x = second
    x1 = 0
    x1_100 = (x1/x)*100
    x1_2 = round(x1_100)
    x2 = x - x1
    x2_100 = (x2/x)*100
    x2_2 = round(x2_100)
    while not x1 == x:
        print("\r"+sys.color.green("▇")*x1_2+"▇"*x2_2, "{}/{}".format(x2,x),end="\r")
        x1 = x1 + 1
        x2 = x - x1
        x1_100 = (x1/x)*100
        x1_2 = round(x1_100)
        x2 = x - x1
        x2_100 = (x2/x)*100
        x2_2 = round(x2_100)
        t.sleep(1)
    print("  "*100)
def minute(minute):
    x = 60*minute
    x1 = 0
    x1_100 = (x1/x)*100
    x1_2 = round(x1_100)
    x2 = x - x1
    x2_100 = (x2/x)*100
    x2_2 = round(x2_100)
    while not x1 == x:
        print("\r"+sys.color.green("▇")*x1_2+"▇"*x2_2,end="\r")
        x1 = x1 + 1
        x2 = x - x1
        x1_100 = (x1/x)*100
        x1_2 = round(x1_100)
        x2 = x - x1
        x2_100 = (x2/x)*100
        x2_2 = round(x2_100)
        t.sleep(1)
    print("  "*100)
def hour(hour):
    x = 360*hour
    x1 = 0
    x1_100 = (x1/x)*100
    x1_2 = round(x1_100)
    x2 = x - x1
    x2_100 = (x2/x)*100
    x2_2 = round(x2_100)
    while not x1 == x:
        print("\r"+sys.color.green("▇")*x1_2+"▇"*x2_2, end="\r")
        x1 = x1 + 1
        x2 = x - x1
        x1_100 = (x1/x)*100
        x1_2 = round(x1_100)
        x2 = x - x1
        x2_100 = (x2/x)*100
        x2_2 = round(x2_100)
        t.sleep(1)
    print("  "*100)