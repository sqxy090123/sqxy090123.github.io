#337e4ece-d2ec-11ed-9c6a-1f7acc9970b6

def black(word):
    cw = "\033[30m{}\033[0m".format(word)
    return cw
def red(word):
    cw = "\033[31m{}\033[0m".format(word)
    return cw
def green(word):
    cw = "\033[32m{}\033[0m".format(word)
    return cw
def yellow(word):
    cw = "\033[33m{}\033[0m".format(word)
    return cw
def blue(word):
    cw = "\033[34m{}\033[0m".format(word)
    return cw
def purple(word):
    cw = "\033[35m{}\033[0m".format(word)
    return cw
