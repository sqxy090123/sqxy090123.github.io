#d8dd39e2-d2e8-11ed-9ade-dbd22c712f1b
import uuid
import time
import os
from dll.system import log
from dll.system import color


def __Del_Empty_File__(file_name):
    try:
        os.remove(file_name)
    except Exception as Err:
        print("删除失败\n返回信息:\n\t{}\n请前往日志(lasted_log.txt)查看具体错误原因".format(Err))
        log.write.Error_time(Err, "check_uuid")
        return Err
    print("删除成功")
    return "Complete"


class NoPathInName(Exception):
    def __init__(self, message):
        self.message = message


def check_more(dll_name):
    a = len(dll_name)
    b = -1
    c = 0
    while not c == a:
        b = b + 1
        c = c + 1
        aname = dll_name[b:c]
        dname = "".join(aname)
        with open(dname,"r+") as ck:
            try:
                check = ck.readlines()[0]
                ch = 0
            except IndexError:
                print("'{}' 是空文件".format(dname.replace(".py","").replace("/",".")))
                ch = 1
            if ch == 0:
                if "#" in check:
                    check = check.replace("#", "")
                if "\n" in check:
                    check = check.replace("\n","")
                else:
                    print(color.yellow("[Warning]"),"'{}' 是一个注册uuid为 '{}' 的空壳文件\n是否删除?".format(dname.replace(".py","").replace("/","."), check))
                    a = input("")
                    if a == "n":
                        pass
                    if a == "N":
                        pass
                    if a == "no":
                        pass
                    if a == "No":
                        pass
                    if a == "NO":
                        pass
                    if a == "y":
                        return __Del_Empty_File__(dname)
                    if a == "Y":
                        return __Del_Empty_File__(dname)
                    if a == "yes":
                        return __Del_Empty_File__(dname)
                    if a == "Yes":
                        return __Del_Empty_File__(dname)
                    if a == "YES":
                        return __Del_Empty_File__(dname)
                    else:
                        pass
                if check == '':
                    print("'{}' 不是一个注册的文件".format(dname.replace(".py","").replace("/",".")))
                elif not " " in check:
                    print("'{}' 的注册uuid为 '{}'".format(dname.replace(".py","").replace("/","."), check))
                else:
                    print("'{}' 不是一个注册的文件".format(dname.replace(".py","").replace("/",".")))
    

def check(dll_name):
    if "/" in dll_name:
        #raise NoPathInName("[Err-Path-01] {}is a path".format(dll_name))
        print(color.yellow("[Warning]"), "There is a path in '{}', but should be no path".format(dll_name))
        return False
    elif "\\" in dll_name:
        #raise NoPathInName("[Err-Path-01] {}is a path".format(dll_name))
        print(color.yellow("[Warning]"), "'{}' is a path, but it should not be a path!".format(dll_name))
        return False
    try:
        with open("$/dll/system/"+dll_name+".py","r+") as ck:
            check = ck.readlines()[0]
    except FileNotFoundError:
        try:
            with open("$/dll/*/"+dll_name+".py","r+"):
                check = ck.readlines()[0]
        except FileNotFoundError:
            print("没有找到插件'{}'".format(dll_name))
            return None
    if "#" in check:
        check = check.replace("#", "")
        if "\n" in check:
            check = check.replace("\n","")
        else:
            print(color.yellow("[Warning]"),"'{}' 是一个注册uuid为 '{}' 的空壳文件\n是否删除?".format(dll_name, check))
            a = input("")
            if a == "n":
                return False
            if a == "N":
                return False
            if a == "no":
                return False
            if a == "No":
                return False
            if a == "NO":
                return False
            if a == "y":
                return __Del_Empty_File__("$/dll/system/"+dll_name+".py")
            if a == "Y":
                return __Del_Empty_File__("$/dll/system/"+dll_name+".py")
            if a == "yes":
                return __Del_Empty_File__("$/dll/system/"+dll_name+".py")
            if a == "Yes":
                return __Del_Empty_File__("$/dll/system/"+dll_name+".py")
            if a == "YES":
                return __Del_Empty_File__("$/dll/system/"+dll_name+".py")
            else:
                return None
    else:
        print("'{}' 不是一个注册的文件".format(dll_name))
        return False
    if check == '':
        print("'{}' 不是一个注册的文件".format(dll_name))
        return False
    elif not " " in check:
        pass
    else:
        print("'{}' 不是一个注册的文件".format(dll_name))
        return False
    print("'{}' 的注册uuid为 '{}'".format(dll_name, check))
    return True