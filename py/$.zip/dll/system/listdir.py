#fb7e747c-d2fa-11ed-a26e-7330e0c4bf10
import os
from dll import system as sys
from dll.system import log
class DictionaryNameNotFoundError(Exception):
    def __init__(self, message):
        self.message = message


def _():
    d = input('')
    if d == '':
        da = 0
        d = None
    else:
        da = 1
    try:
        dir = str(os.listdir(d))
    except Exception as Err:
        log.write.Error_time("{}".format(Err),'listdir')
        exit()
    dir = dir.replace(',','\n├─')
    if da == 1:
        dir = dir.replace('[','{}\n├─ '.format(d))
    else:
        dir = dir.replace('[','.\n├─ ')
    dir = dir.replace(']','\r└─')
    dir = dir.replace('\n ','\n├─')
    dir = dir[::-1]
    dir = dir[::-1]
    sys.log.write.Info_time("列出文件夹'{}'内的文件, 文件夹".format(d), 'listdir')
    return("{}".format(dir))


def _s():
    d = input('')
    
    
    