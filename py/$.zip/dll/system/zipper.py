#40f1e2f8-d2fd-11ed-bf24-93d9d203ec3a
from dll import system as sys
from dll.system import log
import zipfile
import uuid
import time


def list_zip(zipfile_name):
    z = zipfile.Zipfile(zipfile_name)
    return(z.namelist())


def create(nane):
    try:
        tz = zipfile.Zipfile(name,"r")
        print(sys.color.yellow("已经存在文件 '{}'".format(name)))
    except FileNotFoundError:
        pass
    try:
        z = zipfile.ZipFile(name,"w")
        z.close()
    except Exception as Err:
        log.write.Error_time("{}".format(Err), "zipper")


def is_zip(name):
    return (zipfile.is_zipfile(name))


def write(zipname, filename, txt):
    if not filename in list_zip(zipname):
        pass
    else:
        print("在压缩文件 '{}' 里已经存在文件 '{}'".format(zipname.replace(".zip", ""),filename))
    z = zipfile.ZipFile(zipname,"a")
    z.writestr(filename, txt)
    z.close()

